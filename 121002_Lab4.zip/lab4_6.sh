hr=$(date +"%H")
if [ $hr -lt 12 ]
then 
	echo "Good morning!!!"
elif [ $hr -lt 15 ]
then
	echo "Good afternoon!!!"
else 
	echo "Good evening!!!"
fi
