echo "Number:"
read n
a=0
i=2
num=`expr $n / 2`
while [ "$i" -le "$num" ]
do 
	
	y=`expr $n % $i`
	
	if [ "$y" -eq 0 ]
	then
		echo "Not a prime number"
		a=1
	break		
	fi
	i=`expr $i + 1`
done 
if [ $a -eq 0 ]
then
echo "Prime number"
fi
