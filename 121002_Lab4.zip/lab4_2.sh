echo "Enter Pattern:"
read a;
echo "Enter File name:"
read b;
if grep $a $b 
then              
echo Pattern found ;
else
echo Pattern not found;
fi
