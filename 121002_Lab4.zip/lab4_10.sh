echo "Enter:"
read flnm
wc -w "$flnm"
