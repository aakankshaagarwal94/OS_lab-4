echo " Enter Salary "
read a
if [ $a -lt 1500 ] 
	then
	echo "Enter Salary Value more than 2000."

	else
		hra=`expr $a \* 12`
		hra=`expr $hra \/ 100`
	echo "The HRA of the Salary entered is Rs $hra." 

fi
