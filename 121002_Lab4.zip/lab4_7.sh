ls -l "$1"
echo "Do you want to revoke the permission of a file?: "
read prmsn
if [ $prmsn == y -o $prmsn == Y ]
then
chmod 111 $1
ls -l "$1"
fi
