echo "Enter a number"
read i
echo "The Input Number is $i."
a=`expr $i \+ 1 `
b=`expr $a \* $i `
ans=`expr $b \/ 2 `
echo The Sum of $i Numbers is $ans.
