clear
a=1
while [ $a -ne 0 ]
do
	echo Enter Number 0-50
	read i	
	if [ $i -gt 50 ] 
	then
	    echo Number entered is wrong
	elif [ $i -lt 0 ]
	then
		echo Number entered is wrong
	else 
		b=`expr $i \* $i`
		echo Square of the Given Number is $b.
	fi

	echo "Do You want to continue?(1/0)" 
	read a
done
