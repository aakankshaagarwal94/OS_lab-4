echo "Enter filename: "
read flnm
sed -n '$=' "$flnm"
