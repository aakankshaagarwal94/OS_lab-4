echo "Enter file: "
read flnm
echo "Spaces: "
wc -l  "$flnm"
